# SODA Onboarding Flow, Instructions and Logic States

*Build-ready spec for the door-to-badge onboarding. Companion to `SODA-Onboarding-Flow.html`.*

---

## 1. The one-line model

**Visible first, grow at your pace.** A name and a way to reach you makes you a real, visible participant. Building a card and earning a verified badge are optional, self-paced steps that never block participation.

Three principles the whole flow obeys:

1. **The door is the only hard gate to enter.** After it, participation is never blocked.
2. **Card and badge are invitations, not tolls.** They can be skipped, deferred, or ignored.
3. **Verification gates one thing: connecting.** You can enter, be visible, and read anyone's card unverified. To *add a connection*, you must be verified. The badge is both a trust signal and the key to connecting; it never gates entry or browsing.

---

## 2. The flow at a glance

```
  DOOR ──▶ FLOOR ──▶ ROOM (hub) ──▶ browse cards, mingle
   0        1          2  │
                          ├──▶ CARD BUILD (3)  optional, returns to hub
                          └──▶ VERIFY (4)      optional, returns to hub
```

Progress meter (always visible): **Visible → Card → Badge.** "Visible" lights the moment you enter; the other two fill in whenever the person chooses.

---

## 3. Screen-by-screen, with gates

### Screen 0, Door
- **Shows:** one room code field (prefilled, e.g. `MOSA`) and a "scan a table QR" alternate.
- **CTA:** Enter the room.
- **Gate (hard, minimal):** room code is non-empty.
- **Rule:** one code, one door, regardless of which partner invited the person. QR is a convenience layered on top; the typed code is the reliable spine so a slow camera never stalls the line.

### Screen 1, Floor
- **Shows:** name field, an **Email / Text** toggle, and one contact field that adapts to the toggle.
- **CTA:** Step inside.
- **Gate (hard, minimal, this is the real door):** name is non-empty **and** contact is valid for the chosen channel.
  - email valid = contains `@`
  - phone valid = at least 10 digits after stripping non-digits
- **On pass:** set `youState = starter`, go to Room, confirm with "You are in the room."
- **Rule:** no verification here. Entry is optimistic. The contact chosen here decides the verification channel later.

### Screen 2, Room (the hub)
- **Shows:** a gentle self-paced nudge (see §5), the room label "In the room now / Tap a card to open it," and the grid: **You** first, then people.
- **CTA:** Done for now (loops the demo / ends the session).
- **Gates:** none. Participation is never blocked here.
- **Interactions:**
  - Tap a **person's** card → opens their card sheet (read-only view: name, role, verified pill if verified, match reason, offers, looking-for) plus an **Add connection** button.
  - Tap **your own** card → opens the card editor (Screen 3).
  - Verified people show a checkmark in the card's top-right corner; unverified people show nothing.
- **Add connection gate:** the Add connection button checks `youState`.
  - If `verified`: the connection is added, button becomes "Connected," success toast fires.
  - If not verified: the **verify-required gate toast** appears ("Verify your card to add connections") with a "Verify now" action that routes to Screen 4. No connection is made.

### Screen 3, Card build (optional)
- **Shows:** a live card preview, a "how you show up" role field, Offers chips, Looking-for chips.
- **CTA:** Save my card → set `youState = card`, return to hub. **Ghost CTA:** I will finish later → return to hub, state unchanged.
- **Gate:** none. Saving is encouraged, never forced.
- **Rule:** identity and chips stay separate (Me face is identity only; offers/needs are their own thing).

### Screen 4, Verify (optional)
- **Shows:** a six-box OTP, delivered by the chosen channel. Copy and headline adapt: "Verify your email" / "Verify your number," and "We sent a code by email/text to {value}." Demo shortcut fills `402198`.
- **CTA:** Verify my code → on complete OTP, set `youState = verified`, return to hub, badge earned. **Ghost CTA:** Maybe later → return to hub, state unchanged.
- **Gate to earn the badge only:** all six digits entered. This gates the *badge*, nothing else.

---

## 4. Logic states (the state machine)

Three pieces of state drive everything.

### `contactMethod` : `email | phone`
Chosen on the Floor via the toggle. Drives (a) which validation runs at the Floor gate and (b) which channel the verification code is sent by. Default `email`.

### `youState` : `starter | card | verified`
A monotonic climb. It only ever moves forward.

| State | Reached by | Card details | Badge | Room grid card shows |
| --- | --- | --- | --- | --- |
| `starter` | passing the Floor gate | none | none | name + "Just walked in" + **dashed placeholder** in corner |
| `card` | saving on Screen 3 | role + offers/needs | none | name + role + dashed placeholder |
| `verified` | completing OTP on Screen 4 | (whatever exists) | earned | name + role + **green check** in corner |

### `connections` : `array of person ids`
Who the person has connected with. **Writing to this requires `youState = verified`.** Reading cards does not. Attempting to add while unverified triggers the gate toast instead of a write.

### `nudgeDismissed` : `boolean`
Whether the person tapped "Later" on the current gentle nudge. Resets to `false` whenever they enter a spoke or `youState` advances (so the next gentle step gets one clean surfacing).

### Derived: the progress meter
- **Visible** = entered (`screen ≥ room` or `youState ≠ starter`)
- **Card** = `youState ∈ {card, verified}`
- **Badge** = `youState = verified`

---

## 5. The nudge logic (self-paced, dismissible)

The hub shows at most one gentle nudge, chosen by `youState`:

| `youState` | Nudge | Primary action | Dismiss ("Later") |
| --- | --- | --- | --- |
| `starter` | "You're in, {name}. Add what you offer…" | Add to my card → Screen 3 | collapses to a quiet strip with a small "Finish it" link |
| `card` | "Nice card. Whenever you like, verify to earn a badge." | Verify for a badge → Screen 4 | collapses to a quiet strip with a small "Verify" link |
| `verified` | (none) | n/a | n/a |

Rules: the nudge **never blocks**. Dismissing does not remove the path, it shrinks it to a quiet, always-available line. A nudge surfaces fresh once per state; after that the person is trusted.

---

## 6. Transition map

```
DOOR ─(code ok)─▶ FLOOR ─(name + valid contact)─▶ ROOM [youState=starter]
                                                    │
   ROOM ─(tap nudge / tap You card)──────────────▶ CARD BUILD
   CARD BUILD ─(Save)────────────────────────────▶ ROOM [youState=card]
   CARD BUILD ─(Finish later)────────────────────▶ ROOM [unchanged]
                                                    │
   ROOM ─(tap verify nudge / tap placeholder)────▶ VERIFY
   VERIFY ─(OTP complete)────────────────────────▶ ROOM [youState=verified]
   VERIFY ─(Maybe later)─────────────────────────▶ ROOM [unchanged]
                                                    │
   ROOM ─(tap a person)──────────────────────────▶ their card sheet ─(Close)─▶ ROOM
   ROOM ─(Done for now)──────────────────────────▶ end / loop
```

---

## 7. Interaction rules (quick reference)

- Participation (being visible, browsing cards) is **never** gated after the Floor.
- Tapping a **person** opens a read-only card; tapping **yourself** opens the editor.
- The badge corner is the **same top-right spot** whether it holds the dashed placeholder or the earned check, so verifying visibly *fills in* something already reserved.
- The verification channel always follows `contactMethod`. No second contact is collected.
- Guide toasts (top) coach the next step; action toasts (bottom) confirm what happened. Keep them on separate edges.

---

## 8. Toast copy and colors

Two colors, two jobs. **Green = confirm** (something good just happened). **Purple = needs your attention** (a gentle block or nudge). Guide toasts sit on the top edge; action and gate toasts on the bottom edge.

**Guide (top, coaching):**
- Door: one code, one door; keep a typed code as backup so a slow camera never holds the line.
- Floor: a name and a phone or email, and they're already a real participant.
- Room (starter): in and visible now; the card is a soft invitation, not a toll.
- Room (card): card done; the badge is the next gentle step, at their pace.
- Room (verified): all three earned, none forced.
- Card build: a gentle bump, never a wall; save now or finish later.
- Verify: the code can arrive by text or email, whichever they picked; badge, not a gate.

**Action / success (bottom, GREEN, confirming):** "You are in the room," "Card saved," "Verified, you can add connections now," "{name} added to your connections," "Code entered," "No rush, it stays here for you."

**Gate (bottom, PURPLE, needs action):** "Verify your card to add connections. It keeps who you meet real." with a purple "Verify now" button that routes to the verify screen. This is the toast state for the connection gate, and it is the one non-green toast, on purpose, so a required step never looks like a confirmation.

---

## 9. Contract shapes (for the build)

```json
// entry, written when someone passes the Floor gate
{
  "event": "join",
  "room_code": "MOSA",
  "name": "Brent Montgomery",
  "contact": { "method": "email | sms", "value": "..." },
  "you_state": "starter"
}

// session/screen resolution (server decides, client renders)
{
  "screen_state": "door | floor | room | card | verify",
  "you_state": "starter | card | verified",
  "contact_method": "email | sms"
}

// card upsert (Screen 3)
{
  "role": "Founder, Gilchrist",
  "offers": ["Advice", "Mentorship"],
  "needs": ["Collaboration", "Work"],
  "face_rule": "me_face_has_no_chips"
}

// verify (Screen 4) -> unlocks connecting
{ "request": { "channel": "email | sms", "to": "..." } }
{ "submit":  { "code": "402198" } }  ->  { "verified": true, "badge": "verified" }

// add connection (card sheet) -> requires verified
{ "request": { "to_person_id": "maya", "from_verified": true } }
//   if from_verified == false -> reject, return { "gated": "verify_required" }, client shows gate toast
//   if true -> { "connected": true }
```

---

## 10. Clerk mapping (email + SMS)

The prototype's toggle is the front end; **Clerk is the engine.**

- The Floor contact becomes a Clerk identifier: `emailAddress` or `phoneNumber`.
- Verify maps to Clerk's prepare + attempt verification, with strategy `email_code` or `phone_code` matching `contactMethod`.
- The **badge is your app's state**, set when Clerk's verification succeeds. Clerk confirms identity; SODA awards the mark.
- Enable "Phone number + SMS code" in the Clerk dashboard alongside email.

Decisions to lock with Brent before BTW:
- **Phone as primary sign-in vs. second factor.** Primary is fewer steps for a live room; Clerk supports both.
- **SMS cost and volume.** Email is ~free; SMS is a few cents each and adds up across a packed room. Estimate headcount times messages.
- **International + toll-fraud settings.** Clerk manages these, but review before a big event.
- Confirm current dashboard steps and pricing in Clerk's own docs rather than a from-memory recipe; the capability is stable, the specifics move.

---

## 11. What is intentionally NOT gated

Worth stating plainly, because it is the spine of the design:

- Being visible in the room: **not gated** (name + contact only).
- Browsing and opening other people's cards: **not gated.**
- Building your own card: **optional.**
- Adding a connection: **gated behind verification.** This is the one action that requires the badge.
- Earning the badge: **optional**, but it is the key that unlocks connecting.

The only hard requirement to enter is the Floor: a name and one valid way to reach you. The only thing verification gates is connecting.
